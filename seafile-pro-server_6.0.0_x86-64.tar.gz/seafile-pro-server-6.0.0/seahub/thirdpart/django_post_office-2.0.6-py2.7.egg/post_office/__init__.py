VERSION = (2, 0, 6)

from .backends import EmailBackend

default_app_config = 'post_office.apps.PostOfficeConfig'
